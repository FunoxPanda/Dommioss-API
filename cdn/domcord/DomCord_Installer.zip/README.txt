Merci d'avoir téléchargé DomCord.

Pour installer DomCord, téléversez le fichier "index.php" là où vous voulez installer DomCord.
Veillez au fait que l'installateur puisse télécharger des fichiers, en créer et en modifier.

PHP doit être configuré correctement et vous devez supporter le protocole OpenSSL.
Merci !
