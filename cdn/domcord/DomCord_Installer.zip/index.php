<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>DomCord - Préparation du CMS</title>
    <link rel="icon" href="https://api.dommioss.fr/cdn/domcord/installer/icon.png">
    <meta name="robots" content="noindex, nofollow">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link rel="stylesheet" href="https://api.dommioss.fr/cdn/domcord/installer/style.css">
</head>

<body>

    <div class="animation-container">
        <div class="lightning-container">
            <div class="lightning white"></div>
            <div class="lightning red"></div>
        </div>
        <div class="boom-container">
            <div class="shape circle big white"></div>
            <div class="shape circle white"></div>
            <div class="shape triangle big yellow"></div>
            <div class="shape disc white"></div>
            <div class="shape triangle blue"></div>
        </div>
        <div class="boom-container second">
            <div class="shape circle big white"></div>
            <div class="shape circle white"></div>
            <div class="shape disc white"></div>
            <div class="shape triangle blue"></div>
        </div>
        <h2>Nous préparons votre CMS</h2>
        <h3>Merci de bien vouloir patienter, ne fermez pas cette page</h3>
    </div>

    <div class="footer">2022 © All rights reserved to <a href="https://www.dommioss.fr/">DommiossGroup</a></div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <script>
        toastr.options = {
            closeButton: false,
            debug: false,
            newestOnTop: false,
            progressBar: false,
            positionClass: "toast-top-right",
            preventDuplicates: false,
            onclick: null,
            showDuration: 3000,
            hideDuration: 3000,
            timeOut: 300000,
            extendedTimeOut: 300000,
            showEasing: "swing",
            hideEasing: "linear",
            showMethod: "fadeIn",
            hideMethod: "fadeOut"
        }

        <?php
        function downloadCms()
        {
            $data = file_get_contents("https://api.dommioss.fr/domcord/download/last_update.json");
            $data = json_decode($data);

            $filename = $data[1]->dl_filename;

            file_put_contents($filename, fopen($data[1]->dlurl, "r"));

            chmod($filename, 0777);

            $zip = new ZipArchive;
            $res = $zip->open($filename);

            if (!$res || !$zip->extractTo("."))
                return false;

            $zip->close();
            unlink($filename);

            return true;
        }

        function downloadTheme()
        {
            $data = file_get_contents("https://api.dommioss.fr/domcord/download/last_update.json");
            $data = json_decode($data);

            $filename = $data[2]->themeName;

            file_put_contents($filename, fopen($data[2]->themeURL, "r"));

            $zip = new ZipArchive;
            $res = $zip->open($filename);

            if (!$res)
                return false;

            $zip->extractTo("./themes");
            $zip->close();
            unlink($filename);

            return true;
        }

        function createFiles()
        {
            $structureConfig = "./config/";

            if (file_exists($structureConfig)) return false;

            if (!mkdir($structureConfig, 0777, true)) return false;

            if (!fopen($structureConfig . "config.yml", "w")) return false;
            if (!fopen($structureConfig . "database.yml", "w")) return false;
            if (!fopen($structureConfig . "cms_info.yml", "w")) return false;
            if (!fopen($structureConfig . ".htaccess", "w")) return false;

            if (!chmod($structureConfig . "config.yml", 0777)) return false;
            if (!chmod($structureConfig . "cms_info.yml", 0777)) return false;
            if (!chmod($structureConfig . "database.yml", 0777)) return false;
            if (!chmod($structureConfig . ".htaccess", 0777)) return false;

            $fileopen = fopen($structureConfig . ".htaccess", "a");
            fwrite($fileopen, "deny from all");
            fclose($fileopen);

            return true;
        }

        $phpCompatibily = phpversion() >= 7;
        $extensionsCompatibily = extension_loaded("zip") && extension_loaded("pdo") && extension_loaded("openssl");

        if ($phpCompatibily && $extensionsCompatibily) {

            if (createFiles()) {

                echo "toastr['success']('L\'ensemble des fichiers de configuration ont été créés.', 'Pré-installation');\n";

                if (downloadCms()) {

                    echo "toastr['success']('L\'initialisation du CMS est terminée.', 'Installation');\n";

                    if (downloadTheme()) {

                        echo "toastr['success']('L\'installation du <b>CMS DomCord</b> est terminée.', 'Post-Initialisation');\n";
                        echo "toastr['info']('Vous allez être redirigé.', 'Post-Initialisation');\n";
                        echo "setTimeout(() => window.location.reload(), 5000);\n";
                    } else {

                        echo "toastr['error']('Erreur lors du téléchargement des thèmes.', 'Post-Initialisation');\n";
                        echo "toastr['error']('L\'installation de DomCord a été abandonnée.', 'Post-installation');\n";
                    }
                } else {

                    echo "toastr['warning']('Erreur lors du téléchargement et/ou l\'extraction de l\'archive.', 'Installation');\n";
                    echo "toastr['error']('L\'installation de DomCord a été abandonnée.', 'Installation');\n";
                }
            } else {
                echo "toastr['warning']('Les fichiers de configuration n\'ont pas pu être créés. Supprimez le dossier <b>config/</b> s\'il existe et/ou contactez l\'administrateur de votre serveur.', 'Pré-installation');\n";
                echo "toastr['warning']('L\'erreur peut provenir d\'un niveau de permissions insuffisant, placez votre répertoire au niveau de permissions <b>777</b>.', 'Permissions');\n";
                echo "toastr['error']('L\'installation de DomCord a été abandonnée.', 'Pré-installation');\n";
            }
        } else {

            if ($phpCompatibily)
                echo "toastr['info']('Vous possédez une version correcte de PHP.', 'Vérification');\n";
            else
                echo "toastr['error']('Vous possédez une version incorrecte de PHP (" . phpversion() . " < 7.0.0.0).', 'Vérification');\n";

            if ($extensionsCompatibily)
                echo "toastr['info']('L\'ensemble des extensions PHP sont présentes', 'Vérification');\n";
            else
                echo "toastr['warning']('Une de ces extensions n\'est pas présente sur votre serveur: <b>ZIP, PDO, OPENSSL</b>', 'Vérification');\n";

            echo "toastr['error']('L\'installation a été annulée car certains prérequis ne sont pas remplis', 'Vérification');\n";
        }
        ?>
    </script>
</body>

</html>